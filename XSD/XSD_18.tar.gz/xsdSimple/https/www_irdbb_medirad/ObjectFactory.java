//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2020.01.13 à 06:24:34 PM CET 
//


package https.www_irdbb_medirad;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the https.www_irdbb_medirad package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NonDicomFileSetDescriptor_QNAME = new QName("https://www.irdbb-medirad.com", "NonDicomFileSetDescriptor");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: https.www_irdbb_medirad
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link VOI }
     * 
     */
    public VOI createVOI() {
        return new VOI();
    }

    /**
     * Create an instance of {@link DICOMDataContainer }
     * 
     */
    public DICOMDataContainer createDICOMDataContainer() {
        return new DICOMDataContainer();
    }

    /**
     * Create an instance of {@link NonDICOMDataContainer }
     * 
     */
    public NonDICOMDataContainer createNonDICOMDataContainer() {
        return new NonDICOMDataContainer();
    }

    /**
     * Create an instance of {@link NonDicomFileSetDescriptor }
     * 
     */
    public NonDicomFileSetDescriptor createNonDicomFileSetDescriptor() {
        return new NonDicomFileSetDescriptor();
    }

    /**
     * Create an instance of {@link AbsorbedDoseCalculationInROIInHybridDosimetry }
     * 
     */
    public AbsorbedDoseCalculationInROIInHybridDosimetry createAbsorbedDoseCalculationInROIInHybridDosimetry() {
        return new AbsorbedDoseCalculationInROIInHybridDosimetry();
    }

    /**
     * Create an instance of {@link ROIIdentifierUsedContainer }
     * 
     */
    public ROIIdentifierUsedContainer createROIIdentifierUsedContainer() {
        return new ROIIdentifierUsedContainer();
    }

    /**
     * Create an instance of {@link ROIPlanarActivityDetermination }
     * 
     */
    public ROIPlanarActivityDetermination createROIPlanarActivityDetermination() {
        return new ROIPlanarActivityDetermination();
    }

    /**
     * Create an instance of {@link PlanarDataAcquisition }
     * 
     */
    public PlanarDataAcquisition createPlanarDataAcquisition() {
        return new PlanarDataAcquisition();
    }

    /**
     * Create an instance of {@link CTNumberCalibrationCurveReference }
     * 
     */
    public CTNumberCalibrationCurveReference createCTNumberCalibrationCurveReference() {
        return new CTNumberCalibrationCurveReference();
    }

    /**
     * Create an instance of {@link CountsPerVOIAtTimePointContainer }
     * 
     */
    public CountsPerVOIAtTimePointContainer createCountsPerVOIAtTimePointContainer() {
        return new CountsPerVOIAtTimePointContainer();
    }

    /**
     * Create an instance of {@link DataActivityPerROIAtTimePointContainer }
     * 
     */
    public DataActivityPerROIAtTimePointContainer createDataActivityPerROIAtTimePointContainer() {
        return new DataActivityPerROIAtTimePointContainer();
    }

    /**
     * Create an instance of {@link NMRelevantCalibrationReference }
     * 
     */
    public NMRelevantCalibrationReference createNMRelevantCalibrationReference() {
        return new NMRelevantCalibrationReference();
    }

    /**
     * Create an instance of {@link CurveFittingMethod }
     * 
     */
    public CurveFittingMethod createCurveFittingMethod() {
        return new CurveFittingMethod();
    }

    /**
     * Create an instance of {@link VOIActivityDetermination }
     * 
     */
    public VOIActivityDetermination createVOIActivityDetermination() {
        return new VOIActivityDetermination();
    }

    /**
     * Create an instance of {@link HybridDosimetryworkflow }
     * 
     */
    public HybridDosimetryworkflow createHybridDosimetryworkflow() {
        return new HybridDosimetryworkflow();
    }

    /**
     * Create an instance of {@link VOIContainer }
     * 
     */
    public VOIContainer createVOIContainer() {
        return new VOIContainer();
    }

    /**
     * Create an instance of {@link ActivityScaling }
     * 
     */
    public ActivityScaling createActivityScaling() {
        return new ActivityScaling();
    }

    /**
     * Create an instance of {@link CTRelevantCalibrationReference }
     * 
     */
    public CTRelevantCalibrationReference createCTRelevantCalibrationReference() {
        return new CTRelevantCalibrationReference();
    }

    /**
     * Create an instance of {@link HybridDosimetryViaAbsorbedDoseRateCalculation }
     * 
     */
    public HybridDosimetryViaAbsorbedDoseRateCalculation createHybridDosimetryViaAbsorbedDoseRateCalculation() {
        return new HybridDosimetryViaAbsorbedDoseRateCalculation();
    }

    /**
     * Create an instance of {@link PlanarDataSegmentationWithRegistrationAndPropagation }
     * 
     */
    public PlanarDataSegmentationWithRegistrationAndPropagation createPlanarDataSegmentationWithRegistrationAndPropagation() {
        return new PlanarDataSegmentationWithRegistrationAndPropagation();
    }

    /**
     * Create an instance of {@link CTNumberCalibrationCurve }
     * 
     */
    public CTNumberCalibrationCurve createCTNumberCalibrationCurve() {
        return new CTNumberCalibrationCurve();
    }

    /**
     * Create an instance of {@link CountsPerROIAtTimePoint }
     * 
     */
    public CountsPerROIAtTimePoint createCountsPerROIAtTimePoint() {
        return new CountsPerROIAtTimePoint();
    }

    /**
     * Create an instance of {@link PlanarDataSegmentationWithoutRegistration }
     * 
     */
    public PlanarDataSegmentationWithoutRegistration createPlanarDataSegmentationWithoutRegistration() {
        return new PlanarDataSegmentationWithoutRegistration();
    }

    /**
     * Create an instance of {@link AbsorbedDoseRateCalculationInHybridDosimetry }
     * 
     */
    public AbsorbedDoseRateCalculationInHybridDosimetry createAbsorbedDoseRateCalculationInHybridDosimetry() {
        return new AbsorbedDoseRateCalculationInHybridDosimetry();
    }

    /**
     * Create an instance of {@link ROI }
     * 
     */
    public ROI createROI() {
        return new ROI();
    }

    /**
     * Create an instance of {@link MeanAbsorbedDoseRateInVOIContainer }
     * 
     */
    public MeanAbsorbedDoseRateInVOIContainer createMeanAbsorbedDoseRateInVOIContainer() {
        return new MeanAbsorbedDoseRateInVOIContainer();
    }

    /**
     * Create an instance of {@link PatientOrganMassInHybridDosimetry }
     * 
     */
    public PatientOrganMassInHybridDosimetry createPatientOrganMassInHybridDosimetry() {
        return new PatientOrganMassInHybridDosimetry();
    }

    /**
     * Create an instance of {@link DataActivityPerROIAtTimePoint }
     * 
     */
    public DataActivityPerROIAtTimePoint createDataActivityPerROIAtTimePoint() {
        return new DataActivityPerROIAtTimePoint();
    }

    /**
     * Create an instance of {@link SumAndScalingEnergyDepositionRate }
     * 
     */
    public SumAndScalingEnergyDepositionRate createSumAndScalingEnergyDepositionRate() {
        return new SumAndScalingEnergyDepositionRate();
    }

    /**
     * Create an instance of {@link TimeActivityCurveFit }
     * 
     */
    public TimeActivityCurveFit createTimeActivityCurveFit() {
        return new TimeActivityCurveFit();
    }

    /**
     * Create an instance of {@link ElementOfCTNumberCalibrationCurve }
     * 
     */
    public ElementOfCTNumberCalibrationCurve createElementOfCTNumberCalibrationCurve() {
        return new ElementOfCTNumberCalibrationCurve();
    }

    /**
     * Create an instance of {@link DataActivityPerVOIAtTimePoint }
     * 
     */
    public DataActivityPerVOIAtTimePoint createDataActivityPerVOIAtTimePoint() {
        return new DataActivityPerVOIAtTimePoint();
    }

    /**
     * Create an instance of {@link ROIcontainer }
     * 
     */
    public ROIcontainer createROIcontainer() {
        return new ROIcontainer();
    }

    /**
     * Create an instance of {@link RegistrationVOISegmentation }
     * 
     */
    public RegistrationVOISegmentation createRegistrationVOISegmentation() {
        return new RegistrationVOISegmentation();
    }

    /**
     * Create an instance of {@link SPECTDataAcquisitionAndProcessing }
     * 
     */
    public SPECTDataAcquisitionAndProcessing createSPECTDataAcquisitionAndProcessing() {
        return new SPECTDataAcquisitionAndProcessing();
    }

    /**
     * Create an instance of {@link SPECTAcqCTAcqAndReconstruction }
     * 
     */
    public SPECTAcqCTAcqAndReconstruction createSPECTAcqCTAcqAndReconstruction() {
        return new SPECTAcqCTAcqAndReconstruction();
    }

    /**
     * Create an instance of {@link DataActivityPerVOIAtTimePointContainer }
     * 
     */
    public DataActivityPerVOIAtTimePointContainer createDataActivityPerVOIAtTimePointContainer() {
        return new DataActivityPerVOIAtTimePointContainer();
    }

    /**
     * Create an instance of {@link TimeIntegratedActivityPerROIcontainer }
     * 
     */
    public TimeIntegratedActivityPerROIcontainer createTimeIntegratedActivityPerROIcontainer() {
        return new TimeIntegratedActivityPerROIcontainer();
    }

    /**
     * Create an instance of {@link TimePointIdentifierUsedContainer }
     * 
     */
    public TimePointIdentifierUsedContainer createTimePointIdentifierUsedContainer() {
        return new TimePointIdentifierUsedContainer();
    }

    /**
     * Create an instance of {@link ROIIdentifierContainer }
     * 
     */
    public ROIIdentifierContainer createROIIdentifierContainer() {
        return new ROIIdentifierContainer();
    }

    /**
     * Create an instance of {@link TimeAbsorbedDoseRateCurveFit }
     * 
     */
    public TimeAbsorbedDoseRateCurveFit createTimeAbsorbedDoseRateCurveFit() {
        return new TimeAbsorbedDoseRateCurveFit();
    }

    /**
     * Create an instance of {@link ProcessExecutionContext }
     * 
     */
    public ProcessExecutionContext createProcessExecutionContext() {
        return new ProcessExecutionContext();
    }

    /**
     * Create an instance of {@link EnergyDepositionRatePerVOIAtTimePointContainer }
     * 
     */
    public EnergyDepositionRatePerVOIAtTimePointContainer createEnergyDepositionRatePerVOIAtTimePointContainer() {
        return new EnergyDepositionRatePerVOIAtTimePointContainer();
    }

    /**
     * Create an instance of {@link PlanarDataAcquisitionAndProcessing }
     * 
     */
    public PlanarDataAcquisitionAndProcessing createPlanarDataAcquisitionAndProcessing() {
        return new PlanarDataAcquisitionAndProcessing();
    }

    /**
     * Create an instance of {@link ElementsOfCTNumberCalibrationCurve }
     * 
     */
    public ElementsOfCTNumberCalibrationCurve createElementsOfCTNumberCalibrationCurve() {
        return new ElementsOfCTNumberCalibrationCurve();
    }

    /**
     * Create an instance of {@link SPECTReconstruction }
     * 
     */
    public SPECTReconstruction createSPECTReconstruction() {
        return new SPECTReconstruction();
    }

    /**
     * Create an instance of {@link NonDICOMData }
     * 
     */
    public NonDICOMData createNonDICOMData() {
        return new NonDICOMData();
    }

    /**
     * Create an instance of {@link EnergyDepositionRateCalculationInHybridDosimetry }
     * 
     */
    public EnergyDepositionRateCalculationInHybridDosimetry createEnergyDepositionRateCalculationInHybridDosimetry() {
        return new EnergyDepositionRateCalculationInHybridDosimetry();
    }

    /**
     * Create an instance of {@link AdministeredActivity }
     * 
     */
    public AdministeredActivity createAdministeredActivity() {
        return new AdministeredActivity();
    }

    /**
     * Create an instance of {@link MeanAbsorbedDoseInVOIContainer }
     * 
     */
    public MeanAbsorbedDoseInVOIContainer createMeanAbsorbedDoseInVOIContainer() {
        return new MeanAbsorbedDoseInVOIContainer();
    }

    /**
     * Create an instance of {@link DICOMData }
     * 
     */
    public DICOMData createDICOMData() {
        return new DICOMData();
    }

    /**
     * Create an instance of {@link TimePointIdentifierContainer }
     * 
     */
    public TimePointIdentifierContainer createTimePointIdentifierContainer() {
        return new TimePointIdentifierContainer();
    }

    /**
     * Create an instance of {@link MeanAbsorbedDoseInVOI }
     * 
     */
    public MeanAbsorbedDoseInVOI createMeanAbsorbedDoseInVOI() {
        return new MeanAbsorbedDoseInVOI();
    }

    /**
     * Create an instance of {@link PlanarDataCorrections }
     * 
     */
    public PlanarDataCorrections createPlanarDataCorrections() {
        return new PlanarDataCorrections();
    }

    /**
     * Create an instance of {@link TimePointDescription }
     * 
     */
    public TimePointDescription createTimePointDescription() {
        return new TimePointDescription();
    }

    /**
     * Create an instance of {@link FileNameList }
     * 
     */
    public FileNameList createFileNameList() {
        return new FileNameList();
    }

    /**
     * Create an instance of {@link CountsPerVOIAtTimePoint }
     * 
     */
    public CountsPerVOIAtTimePoint createCountsPerVOIAtTimePoint() {
        return new CountsPerVOIAtTimePoint();
    }

    /**
     * Create an instance of {@link EnergyDepositionRatePerVOIAtTimePoint }
     * 
     */
    public EnergyDepositionRatePerVOIAtTimePoint createEnergyDepositionRatePerVOIAtTimePoint() {
        return new EnergyDepositionRatePerVOIAtTimePoint();
    }

    /**
     * Create an instance of {@link HybridDosimetryViaTimeActivityCurveFit }
     * 
     */
    public HybridDosimetryViaTimeActivityCurveFit createHybridDosimetryViaTimeActivityCurveFit() {
        return new HybridDosimetryViaTimeActivityCurveFit();
    }

    /**
     * Create an instance of {@link RadioBiologicalCalculationInHybridOr3DSlide2Dosimetry }
     * 
     */
    public RadioBiologicalCalculationInHybridOr3DSlide2Dosimetry createRadioBiologicalCalculationInHybridOr3DSlide2Dosimetry() {
        return new RadioBiologicalCalculationInHybridOr3DSlide2Dosimetry();
    }

    /**
     * Create an instance of {@link TimePointDescriptionElement }
     * 
     */
    public TimePointDescriptionElement createTimePointDescriptionElement() {
        return new TimePointDescriptionElement();
    }

    /**
     * Create an instance of {@link ReferencedClinicalResearchStudy }
     * 
     */
    public ReferencedClinicalResearchStudy createReferencedClinicalResearchStudy() {
        return new ReferencedClinicalResearchStudy();
    }

    /**
     * Create an instance of {@link VOIIdentifierContainer }
     * 
     */
    public VOIIdentifierContainer createVOIIdentifierContainer() {
        return new VOIIdentifierContainer();
    }

    /**
     * Create an instance of {@link TimeIntegratedActivityCoefficientPerROI }
     * 
     */
    public TimeIntegratedActivityCoefficientPerROI createTimeIntegratedActivityCoefficientPerROI() {
        return new TimeIntegratedActivityCoefficientPerROI();
    }

    /**
     * Create an instance of {@link TimeIntegratedActivityPerROI }
     * 
     */
    public TimeIntegratedActivityPerROI createTimeIntegratedActivityPerROI() {
        return new TimeIntegratedActivityPerROI();
    }

    /**
     * Create an instance of {@link MeanAbsorbedDoseRateInVOI }
     * 
     */
    public MeanAbsorbedDoseRateInVOI createMeanAbsorbedDoseRateInVOI() {
        return new MeanAbsorbedDoseRateInVOI();
    }

    /**
     * Create an instance of {@link PatientOrganMassInHybridDosimetryContainer }
     * 
     */
    public PatientOrganMassInHybridDosimetryContainer createPatientOrganMassInHybridDosimetryContainer() {
        return new PatientOrganMassInHybridDosimetryContainer();
    }

    /**
     * Create an instance of {@link CountsPerROIAtTimePointContainer }
     * 
     */
    public CountsPerROIAtTimePointContainer createCountsPerROIAtTimePointContainer() {
        return new CountsPerROIAtTimePointContainer();
    }

    /**
     * Create an instance of {@link TimeIntegratedActivityCoefficientPerROIcontainer }
     * 
     */
    public TimeIntegratedActivityCoefficientPerROIcontainer createTimeIntegratedActivityCoefficientPerROIcontainer() {
        return new TimeIntegratedActivityCoefficientPerROIcontainer();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonDicomFileSetDescriptor }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://www.irdbb-medirad.com", name = "NonDicomFileSetDescriptor")
    public JAXBElement<NonDicomFileSetDescriptor> createNonDicomFileSetDescriptor(NonDicomFileSetDescriptor value) {
        return new JAXBElement<NonDicomFileSetDescriptor>(_NonDicomFileSetDescriptor_QNAME, NonDicomFileSetDescriptor.class, null, value);
    }

}
